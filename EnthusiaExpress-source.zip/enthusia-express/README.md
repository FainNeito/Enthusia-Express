# Enthusia Express

A Paper 1.21.x mail plugin focused on offline-only bulk delivery.

## Implemented in this build

- `/mail send <OfflinePlayer>` refuses online recipients.
- 27-slot shipping UI with exactly one shipment slot (center slot 13).
- Only Shulker Boxes and Bundles are accepted.
- Recursive packed-item counting with configurable depth.
- Exact Raw Gold fee (default 1 Raw Gold per packed item).
- Complete ItemStack byte serialization, preserving container contents, names, enchants, PDC and other supported item data.
- SQLite database using WAL mode and a dedicated single DB worker thread.
- `/mail inbox [packages|letters|announcements]` 54-slot tabbed mailbox shell.
- Package claiming.
- CombatLogX access gate with fail-closed behavior when required.
- Return-to-Sender after configurable expiration, followed by return purge.

## Current scope note

Package delivery is feature-complete for the first build. The Letters and Announcements tabs and database types are present, but authoring/open-book behavior is intentionally left as the next module rather than pretending those commands are implemented.

## Build

Requires Java 21.

```bash
./gradlew shadowJar
```

The output JAR will be under `build/libs/EnthusiaExpress-1.0.0.jar`.

If you do not have a Gradle wrapper yet, run `gradle wrapper` once, then use `./gradlew shadowJar`.

## Install

1. Install Paper 1.21.x.
2. Install CombatLogX if `mail.require-combatlogx: true`.
3. Copy the shaded Enthusia Express JAR into `plugins/`.
4. Restart the server.
5. Edit `plugins/EnthusiaExpress/config.yml` as desired.

## Data safety model

Bukkit/Paper ItemStack serialization and deserialization happen on the main server thread. Only SQLite statements execute on the dedicated database worker. This avoids moving Bukkit object access onto an async thread.
