plugins {
    java
    id("com.gradleup.shadow") version "9.0.0-beta17"
}

group = "io.enthusia"
version = "1.0.0"

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(21))
}

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.8-R0.1-SNAPSHOT")
    implementation("org.xerial:sqlite-jdbc:3.50.3.0")
}

tasks {
    shadowJar {
        archiveClassifier.set("")
        relocate("org.sqlite", "io.enthusia.express.libs.sqlite")
    }
    build { dependsOn(shadowJar) }
}
