package io.enthusia.express;

import io.enthusia.express.command.MailCommand;
import io.enthusia.express.db.MailRepository;
import io.enthusia.express.gui.GuiListener;
import io.enthusia.express.gui.MailboxService;
import io.enthusia.express.gui.ShippingService;
import io.enthusia.express.hook.CombatLogXHook;
import io.enthusia.express.mail.ExpirationService;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Objects;

public final class EnthusiaExpressPlugin extends JavaPlugin {
    private MailRepository repository;
    private CombatLogXHook combatHook;
    private ShippingService shippingService;
    private MailboxService mailboxService;
    private ExpirationService expirationService;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        File dbFile = new File(getDataFolder(), "mail.db");
        this.repository = new MailRepository(this, dbFile);
        repository.initialize().join();

        this.combatHook = new CombatLogXHook(this);
        this.shippingService = new ShippingService(this, repository, combatHook);
        this.mailboxService = new MailboxService(this, repository, combatHook);
        this.expirationService = new ExpirationService(this, repository);

        MailCommand command = new MailCommand(this, shippingService, mailboxService, combatHook);
        Objects.requireNonNull(getCommand("mail")).setExecutor(command);
        Objects.requireNonNull(getCommand("mail")).setTabCompleter(command);
        Bukkit.getPluginManager().registerEvents(new GuiListener(shippingService, mailboxService), this);
        expirationService.start();

        getLogger().info("Enthusia Express enabled.");
    }

    @Override
    public void onDisable() {
        if (expirationService != null) expirationService.stop();
        if (repository != null) repository.close();
    }
}
