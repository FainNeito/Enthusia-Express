package io.enthusia.express.command;

import io.enthusia.express.gui.MailboxService;
import io.enthusia.express.gui.ShippingService;
import io.enthusia.express.hook.CombatLogXHook;
import io.enthusia.express.mail.MailType;
import io.enthusia.express.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MailCommand implements CommandExecutor, TabCompleter {
    private final JavaPlugin plugin;
    private final ShippingService shipping;
    private final MailboxService mailbox;
    private final CombatLogXHook combatHook;

    public MailCommand(JavaPlugin plugin, ShippingService shipping, MailboxService mailbox, CombatLogXHook combatHook) {
        this.plugin = plugin;
        this.shipping = shipping;
        this.mailbox = mailbox;
        this.combatHook = combatHook;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        if (!combatHook.mayUseMail(player)) {
            player.sendMessage(Text.msg(plugin.getConfig(), combatHook.isAvailable() ? "combat-blocked" : "combatlogx-missing"));
            return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("inbox")) {
            MailType type = MailType.PACKAGE;
            if (args.length >= 2) {
                type = switch (args[1].toLowerCase(Locale.ROOT)) {
                    case "letters", "letter" -> MailType.LETTER;
                    case "announcements", "announcement", "admin" -> MailType.ANNOUNCEMENT;
                    default -> MailType.PACKAGE;
                };
            }
            mailbox.open(player, type);
            return true;
        }
        if (args[0].equalsIgnoreCase("send")) {
            if (args.length < 2) {
                player.sendMessage("§eUsage: /mail send <OfflinePlayer>");
                return true;
            }
            @SuppressWarnings("deprecation") OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
            if (!target.hasPlayedBefore()) {
                player.sendMessage(Text.msg(plugin.getConfig(), "target-never-joined"));
                return true;
            }
            if (target.getUniqueId().equals(player.getUniqueId())) {
                player.sendMessage("§cYou cannot mail yourself.");
                return true;
            }
            shipping.open(player, target);
            return true;
        }
        player.sendMessage("§e/mail send <OfflinePlayer> §7or §e/mail inbox [packages|letters|announcements]");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return List.of("send", "inbox").stream().filter(s -> s.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        if (args.length == 2 && args[0].equalsIgnoreCase("inbox")) return List.of("packages", "letters", "announcements");
        if (args.length == 2 && args[0].equalsIgnoreCase("send")) {
            String partial = args[1].toLowerCase(Locale.ROOT);
            List<String> names = new ArrayList<>();
            for (OfflinePlayer p : Bukkit.getOfflinePlayers()) {
                if (p.isOnline() || p.getName() == null) continue;
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(partial)) names.add(p.getName());
                if (names.size() >= 20) break;
            }
            return names;
        }
        return List.of();
    }
}
