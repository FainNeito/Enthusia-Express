package io.enthusia.express.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;

public final class GuiListener implements Listener {
    private final ShippingService shipping;
    private final MailboxService mailbox;

    public GuiListener(ShippingService shipping, MailboxService mailbox) {
        this.shipping = shipping;
        this.mailbox = mailbox;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Inventory top = event.getView().getTopInventory();

        if (shipping.owns(player, top)) {
            int raw = event.getRawSlot();
            // Allow normal interaction only with the package slot.
            if (raw != ShippingService.PACKAGE_SLOT) event.setCancelled(true);
            if (raw == ShippingService.CANCEL_SLOT) shipping.cancel(player);
            if (raw == ShippingService.CONFIRM_SLOT) shipping.confirm(player, top);
            return;
        }

        if (mailbox.owns(player)) {
            event.setCancelled(true);
            if (event.getRawSlot() < top.getSize()) mailbox.click(player, event.getRawSlot());
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        shipping.returnPackageOnClose(player, event.getInventory());
        mailbox.close(player);
    }
}
