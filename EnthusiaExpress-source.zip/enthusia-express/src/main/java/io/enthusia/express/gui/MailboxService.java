package io.enthusia.express.gui;

import io.enthusia.express.db.MailRepository;
import io.enthusia.express.hook.CombatLogXHook;
import io.enthusia.express.mail.MailRecord;
import io.enthusia.express.mail.MailType;
import io.enthusia.express.util.ItemCodec;
import io.enthusia.express.util.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.text.DateFormat;
import java.util.*;

public final class MailboxService {
    public static final String TITLE_PREFIX = "Enthusia Express Mailbox";
    private final JavaPlugin plugin;
    private final MailRepository repository;
    private final CombatLogXHook combatHook;
    private final Map<UUID, MailType> filters = new HashMap<>();
    private final Map<UUID, Map<Integer, Long>> visibleIds = new HashMap<>();

    public MailboxService(JavaPlugin plugin, MailRepository repository, CombatLogXHook combatHook) {
        this.plugin = plugin;
        this.repository = repository;
        this.combatHook = combatHook;
    }

    public void open(Player player, MailType type) {
        if (!combatHook.mayUseMail(player)) {
            player.sendMessage(Text.msg(plugin.getConfig(), combatHook.isAvailable() ? "combat-blocked" : "combatlogx-missing"));
            return;
        }
        filters.put(player.getUniqueId(), type);
        repository.listInbox(player.getUniqueId(), type).whenComplete((records, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) return;
            if (error != null) {
                player.sendMessage("§cCould not load your mailbox.");
                return;
            }
            render(player, type, records);
        }));
    }

    private void render(Player player, MailType type, List<MailRecord> records) {
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_PREFIX + " - " + pretty(type));
        inv.setItem(1, tab(Material.CHEST, "§6Packages", type == MailType.PACKAGE));
        inv.setItem(4, tab(Material.WRITABLE_BOOK, "§eLetters", type == MailType.LETTER));
        inv.setItem(7, tab(Material.BELL, "§bAnnouncements", type == MailType.ANNOUNCEMENT));

        Map<Integer, Long> ids = new HashMap<>();
        int slot = 9;
        for (MailRecord record : records) {
            if (slot >= 54) break;
            ItemStack icon;
            if (record.type() == MailType.PACKAGE) {
                ItemStack actual = ItemCodec.decode(record.payload());
                icon = actual.clone();
                ItemMeta meta = icon.getItemMeta();
                List<String> lore = new ArrayList<>();
                lore.add("§7From: §f" + record.senderName());
                lore.add("§7Packed items: §f" + record.packedItemCount());
                lore.add("§7Sent: §f" + DateFormat.getDateTimeInstance().format(new Date(record.createdAt())));
                lore.add("§aClick to claim");
                meta.setLore(lore);
                icon.setItemMeta(meta);
            } else {
                icon = new ItemStack(record.type() == MailType.LETTER ? Material.WRITTEN_BOOK : Material.PAPER);
                ItemMeta meta = icon.getItemMeta();
                meta.setDisplayName(record.type() == MailType.LETTER ? "§eLetter from " + record.senderName() : "§bAdmin Announcement");
                if (record.unread()) {
                    meta.addEnchant(Enchantment.UNBREAKING, 1, true);
                    meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
                }
                icon.setItemMeta(meta);
            }
            inv.setItem(slot, icon);
            ids.put(slot, record.id());
            slot++;
        }
        visibleIds.put(player.getUniqueId(), ids);
        player.openInventory(inv);
        if (records.isEmpty()) player.sendMessage(Text.msg(plugin.getConfig(), "mailbox-empty"));
    }

    public boolean owns(Player player) {
        return player.getOpenInventory().getTitle().startsWith(TITLE_PREFIX);
    }

    public void click(Player player, int rawSlot) {
        if (!combatHook.mayUseMail(player)) {
            player.closeInventory();
            player.sendMessage(Text.msg(plugin.getConfig(), "combat-blocked"));
            return;
        }
        if (rawSlot == 1) { open(player, MailType.PACKAGE); return; }
        if (rawSlot == 4) { open(player, MailType.LETTER); return; }
        if (rawSlot == 7) { open(player, MailType.ANNOUNCEMENT); return; }
        Long id = visibleIds.getOrDefault(player.getUniqueId(), Map.of()).get(rawSlot);
        if (id == null) return;
        repository.get(id).whenComplete((record, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (error != null || record == null || !record.recipient().equals(player.getUniqueId())) return;
            if (record.type() == MailType.PACKAGE) claimPackage(player, record);
            else player.sendMessage("§eLetter/announcement payload support is reserved for the next feature module.");
        }));
    }

    private void claimPackage(Player player, MailRecord record) {
        ItemStack stack = ItemCodec.decode(record.payload());
        // Avoid claiming if the inventory cannot accept the item.
        if (player.getInventory().firstEmpty() == -1) {
            player.sendMessage("§cYou need at least one empty inventory slot to claim this package.");
            return;
        }
        repository.claim(record.id(), player.getUniqueId()).whenComplete((claimed, error) -> Bukkit.getScheduler().runTask(plugin, () -> {
            if (error != null || !Boolean.TRUE.equals(claimed)) {
                player.sendMessage("§cThat package could not be claimed.");
                return;
            }
            Map<Integer, ItemStack> overflow = player.getInventory().addItem(stack);
            overflow.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
            player.sendMessage("§aPackage claimed.");
            open(player, MailType.PACKAGE);
        }));
    }

    public void close(Player player) {
        visibleIds.remove(player.getUniqueId());
    }

    private static ItemStack tab(Material material, String name, boolean selected) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.setDisplayName(name);
        if (selected) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        }
        stack.setItemMeta(meta);
        return stack;
    }

    private static String pretty(MailType type) {
        return switch (type) {
            case PACKAGE -> "Packages";
            case LETTER -> "Letters";
            case ANNOUNCEMENT -> "Announcements";
        };
    }
}
