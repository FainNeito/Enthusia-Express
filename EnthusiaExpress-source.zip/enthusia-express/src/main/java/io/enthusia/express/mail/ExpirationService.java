package io.enthusia.express.mail;

import io.enthusia.express.db.MailRepository;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.concurrent.TimeUnit;

public final class ExpirationService {
    private final JavaPlugin plugin;
    private final MailRepository repository;
    private BukkitTask task;

    public ExpirationService(JavaPlugin plugin, MailRepository repository) {
        this.plugin = plugin;
        this.repository = repository;
    }

    public void start() {
        // The repository work itself is asynchronous; this merely schedules periodic checks.
        task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 20L * 60L, 20L * 60L * 10L);
    }

    private void tick() {
        long now = System.currentTimeMillis();
        long returnHours = plugin.getConfig().getLong("mail.return-after-hours", 168L);
        long purgeHours = plugin.getConfig().getLong("mail.purge-returned-after-hours", 168L);
        repository.findExpiredUnclaimed(now - TimeUnit.HOURS.toMillis(returnHours))
                .thenAccept(records -> records.stream().filter(r -> !r.returnDelivery()).forEach(r -> repository.returnToSender(r)));
        repository.findExpiredReturns(now - TimeUnit.HOURS.toMillis(purgeHours))
                .thenAccept(records -> records.forEach(r -> repository.purge(r.id())));
    }

    public void stop() {
        if (task != null) task.cancel();
    }
}
