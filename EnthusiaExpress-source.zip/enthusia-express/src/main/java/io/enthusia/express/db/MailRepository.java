package io.enthusia.express.db;

import io.enthusia.express.mail.MailRecord;
import io.enthusia.express.mail.MailStatus;
import io.enthusia.express.mail.MailType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.*;

public final class MailRepository {
    private final JavaPlugin plugin;
    private final File dbFile;
    private final ExecutorService executor;
    private Connection connection;

    public MailRepository(JavaPlugin plugin, File dbFile) {
        this.plugin = plugin;
        this.dbFile = dbFile;
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "EnthusiaExpress-SQLite");
            t.setDaemon(true);
            return t;
        });
    }

    public CompletableFuture<Void> initialize() {
        return run(() -> {
            dbFile.getParentFile().mkdirs();
            connection = DriverManager.getConnection("jdbc:sqlite:" + dbFile.getAbsolutePath());
            try (Statement st = connection.createStatement()) {
                st.execute("PRAGMA journal_mode=WAL");
                st.execute("PRAGMA synchronous=NORMAL");
                st.execute("PRAGMA foreign_keys=ON");
                st.execute("""
                    CREATE TABLE IF NOT EXISTS mail (
                      id INTEGER PRIMARY KEY AUTOINCREMENT,
                      sender_uuid TEXT,
                      sender_name TEXT NOT NULL,
                      recipient_uuid TEXT NOT NULL,
                      recipient_name TEXT NOT NULL,
                      type TEXT NOT NULL,
                      status TEXT NOT NULL,
                      payload BLOB NOT NULL,
                      packed_item_count INTEGER NOT NULL DEFAULT 0,
                      created_at INTEGER NOT NULL,
                      updated_at INTEGER NOT NULL,
                      unread INTEGER NOT NULL DEFAULT 1,
                      return_delivery INTEGER NOT NULL DEFAULT 0
                    )
                    """);
                st.execute("CREATE INDEX IF NOT EXISTS idx_mail_recipient_status ON mail(recipient_uuid, status, type)");
                st.execute("CREATE INDEX IF NOT EXISTS idx_mail_expiration ON mail(status, updated_at)");
            }
        });
    }

    public CompletableFuture<Long> insertPackage(UUID sender, String senderName, UUID recipient, String recipientName,
                                                 byte[] payload, int packedCount, boolean returnDelivery) {
        return supply(() -> {
            long now = System.currentTimeMillis();
            String sql = "INSERT INTO mail(sender_uuid,sender_name,recipient_uuid,recipient_name,type,status,payload,packed_item_count,created_at,updated_at,unread,return_delivery) VALUES(?,?,?,?,?,?,?,?,?,?,1,?)";
            try (PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, sender == null ? null : sender.toString());
                ps.setString(2, senderName);
                ps.setString(3, recipient.toString());
                ps.setString(4, recipientName);
                ps.setString(5, MailType.PACKAGE.name());
                ps.setString(6, MailStatus.UNCLAIMED.name());
                ps.setBytes(7, payload);
                ps.setInt(8, packedCount);
                ps.setLong(9, now);
                ps.setLong(10, now);
                ps.setInt(11, returnDelivery ? 1 : 0);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    return rs.next() ? rs.getLong(1) : -1L;
                }
            }
        });
    }

    public CompletableFuture<List<MailRecord>> listInbox(UUID recipient, MailType type) {
        return supply(() -> {
            List<MailRecord> out = new ArrayList<>();
            String sql = "SELECT * FROM mail WHERE recipient_uuid=? AND type=? AND status IN (?,?) ORDER BY created_at DESC LIMIT 45";
            try (PreparedStatement ps = connection.prepareStatement(sql)) {
                ps.setString(1, recipient.toString());
                ps.setString(2, type.name());
                ps.setString(3, MailStatus.UNCLAIMED.name());
                ps.setString(4, MailStatus.RETURNED.name());
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) out.add(read(rs));
                }
            }
            return out;
        });
    }

    public CompletableFuture<MailRecord> get(long id) {
        return supply(() -> {
            try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM mail WHERE id=?")) {
                ps.setLong(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next() ? read(rs) : null;
                }
            }
        });
    }

    public CompletableFuture<Boolean> claim(long id, UUID recipient) {
        return supply(() -> {
            MailRecord current = null;
            try (PreparedStatement read = connection.prepareStatement("SELECT * FROM mail WHERE id=? AND recipient_uuid=? AND status IN (?,?)")) {
                read.setLong(1, id);
                read.setString(2, recipient.toString());
                read.setString(3, MailStatus.UNCLAIMED.name());
                read.setString(4, MailStatus.RETURNED.name());
                try (ResultSet rs = read.executeQuery()) { if (rs.next()) current = read(rs); }
            }
            if (current == null) return false;
            MailStatus next = current.status() == MailStatus.RETURNED ? MailStatus.RETURN_CLAIMED : MailStatus.CLAIMED;
            try (PreparedStatement ps = connection.prepareStatement("UPDATE mail SET status=?, unread=0, updated_at=? WHERE id=? AND recipient_uuid=? AND status=?")) {
                ps.setString(1, next.name());
                ps.setLong(2, System.currentTimeMillis());
                ps.setLong(3, id);
                ps.setString(4, recipient.toString());
                ps.setString(5, current.status().name());
                return ps.executeUpdate() == 1;
            }
        });
    }

    public CompletableFuture<List<MailRecord>> findExpiredUnclaimed(long cutoffMillis) {
        return queryExpired(MailStatus.UNCLAIMED, cutoffMillis);
    }

    public CompletableFuture<List<MailRecord>> findExpiredReturns(long cutoffMillis) {
        return queryExpired(MailStatus.RETURNED, cutoffMillis);
    }

    private CompletableFuture<List<MailRecord>> queryExpired(MailStatus status, long cutoff) {
        return supply(() -> {
            List<MailRecord> out = new ArrayList<>();
            try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM mail WHERE status=? AND updated_at<? LIMIT 200")) {
                ps.setString(1, status.name());
                ps.setLong(2, cutoff);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) out.add(read(rs));
                }
            }
            return out;
        });
    }

    public CompletableFuture<Void> returnToSender(MailRecord record) {
        return run(() -> {
            if (record.sender() == null) { updateStatus(record.id(), MailStatus.PURGED); return; }
            try (PreparedStatement ps = connection.prepareStatement("UPDATE mail SET recipient_uuid=?, recipient_name=?, status=?, unread=1, return_delivery=1, updated_at=? WHERE id=? AND status=?")) {
                ps.setString(1, record.sender().toString());
                ps.setString(2, record.senderName());
                ps.setString(3, MailStatus.RETURNED.name());
                ps.setLong(4, System.currentTimeMillis());
                ps.setLong(5, record.id());
                ps.setString(6, MailStatus.UNCLAIMED.name());
                ps.executeUpdate();
            }
        });
    }

    public CompletableFuture<Void> purge(long id) {
        return run(() -> updateStatus(id, MailStatus.PURGED));
    }

    private void updateStatus(long id, MailStatus status) throws SQLException {
        try (PreparedStatement ps = connection.prepareStatement("UPDATE mail SET status=?, updated_at=? WHERE id=?")) {
            ps.setString(1, status.name());
            ps.setLong(2, System.currentTimeMillis());
            ps.setLong(3, id);
            ps.executeUpdate();
        }
    }

    private MailRecord read(ResultSet rs) throws SQLException {
        String sender = rs.getString("sender_uuid");
        return new MailRecord(
                rs.getLong("id"),
                sender == null ? null : UUID.fromString(sender),
                rs.getString("sender_name"),
                UUID.fromString(rs.getString("recipient_uuid")),
                rs.getString("recipient_name"),
                MailType.valueOf(rs.getString("type")),
                MailStatus.valueOf(rs.getString("status")),
                rs.getBytes("payload"),
                rs.getInt("packed_item_count"),
                rs.getLong("created_at"),
                rs.getLong("updated_at"),
                rs.getInt("unread") != 0,
                rs.getInt("return_delivery") != 0
        );
    }

    private CompletableFuture<Void> run(SqlRunnable task) {
        return CompletableFuture.runAsync(() -> {
            try { task.run(); }
            catch (Exception e) { throw new CompletionException(e); }
        }, executor);
    }

    private <T> CompletableFuture<T> supply(SqlSupplier<T> task) {
        return CompletableFuture.supplyAsync(() -> {
            try { return task.get(); }
            catch (Exception e) { throw new CompletionException(e); }
        }, executor);
    }

    public void close() {
        try {
            executor.submit(() -> {
                try { if (connection != null) connection.close(); }
                catch (SQLException e) { plugin.getLogger().warning("Failed closing SQLite: " + e.getMessage()); }
            }).get(3, TimeUnit.SECONDS);
        } catch (Exception ignored) {}
        executor.shutdownNow();
    }

    @FunctionalInterface private interface SqlRunnable { void run() throws Exception; }
    @FunctionalInterface private interface SqlSupplier<T> { T get() throws Exception; }
}
