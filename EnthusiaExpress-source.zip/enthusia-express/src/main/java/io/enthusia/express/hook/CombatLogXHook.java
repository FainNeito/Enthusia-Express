package io.enthusia.express.hook;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;

public final class CombatLogXHook {
    private final JavaPlugin plugin;

    public CombatLogXHook(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isAvailable() {
        return Bukkit.getPluginManager().isPluginEnabled("CombatLogX");
    }

    public boolean mayUseMail(Player player) {
        boolean required = plugin.getConfig().getBoolean("mail.require-combatlogx", true);
        if (!isAvailable()) return !required;
        try {
            Plugin combatLogX = Bukkit.getPluginManager().getPlugin("CombatLogX");
            Method getCombatManager = combatLogX.getClass().getMethod("getCombatManager");
            Object combatManager = getCombatManager.invoke(combatLogX);
            Method isInCombat = combatManager.getClass().getMethod("isInCombat", Player.class);
            return !(boolean) isInCombat.invoke(combatManager, player);
        } catch (ReflectiveOperationException e) {
            plugin.getLogger().warning("CombatLogX hook failed: " + e.getMessage());
            return !required;
        }
    }
}
